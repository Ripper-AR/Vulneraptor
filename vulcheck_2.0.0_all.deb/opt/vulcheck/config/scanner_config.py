TOOL_NAME = "VulnScope Lite"
INTEGRATION_VERSION = "2.0.0"

DEFAULT_REPORT_DIR = "reports"
DEFAULT_TARGET_FILE = "targets.txt"

EXECUTION_ORDER = [
    "recon",
    "xss",
    "sqli",
    "security_config",
]
